 
      <?php echo Form::open(['url' => 'escolas/store', 'method' => 'POST']); ?> 


       
       <div class="form-group">
         	<?php echo Form::label('username', 'Subdominío', array('class' => 'control-label' )); ?> 
         	<div class="input-group">
	         	<?php echo Form::text('username', null, ['class' => 'form-control ']); ?>	
	         	<span class="input-group-addon">.jumpercursos.com.br</span>
	      	</div> 
         	<div class="clearfix"></div>                  
       </div> 


       <div class="form-group">
         <?php echo Form::label('link_site', 'Link da página padrão', array('class' => 'control-label' )); ?> 
         <div class="input-group">
         	<span class="input-group-addon">http://</span>
         	<?php echo Form::text('link_site', null, ['class' => 'form-control']); ?>

         </div>  
       </div>  


       <div class="form-group">
         <?php echo Form::label('escola', 'Escola', array('class' => 'control-label' )); ?> 
         <?php echo Form::text('escola', null, ['class' => 'form-control']); ?>

       </div> 

       <div class="form-group">
         <?php echo Form::label('email', 'E-mail', array('class' => 'control-label' )); ?> 
         <?php echo Form::text('email', null, ['class' => 'form-control']); ?>

       </div> 


       <div class="form-group">
         <?php echo Form::label('estado', 'Estado', array('class' => 'control-label' )); ?> 
         <?php echo Form::text('estado', null, ['class' => 'form-control']); ?>

       </div> 


       <div class="form-group">
         <?php echo Form::label('cidade', 'Cidade', array('class' => 'control-label' )); ?> 
         <?php echo Form::text('cidade', null, ['class' => 'form-control']); ?>

       </div>


       <div class="form-group">
         <?php echo Form::label('bairro', 'Bairro', array('class' => 'control-label' )); ?> 
         <?php echo Form::text('bairro', null, ['class' => 'form-control']); ?>

       </div> 




       <div class="form-group">
       	<?php echo Form::label('google_code', 'Google code', array('class' => 'control-label' )); ?>

        <?php echo Form::textarea('google_code', null, ['class' => 'form-control']); ?>

      </div>

      <div class="form-group">
       	<?php echo Form::label('rd_code', 'RD code', array('class' => 'control-label' )); ?>

        <?php echo Form::textarea('rd_code', null, ['class' => 'form-control']); ?>

      </div>

      <div class="form-group">
       	<?php echo Form::label('facebook_code', 'Facebook pixel', array('class' => 'control-label' )); ?>

        <?php echo Form::textarea('facebook_code', null, ['class' => 'form-control']); ?>

      </div>



      <div class="form-group">
        <?php echo Form::submit('Enviar', ['class' => 'btn btn-primary']); ?>

      </div>


    <?php echo Form::close(); ?> 

<?php /**PATH Z:\www\subdomain\resources\views/escola/form.blade.php ENDPATH**/ ?>