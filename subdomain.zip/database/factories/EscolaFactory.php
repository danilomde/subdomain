<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Escola;
use Faker\Generator as Faker;

$factory->define(Escola::class, function (Faker $faker) {
    return [
        //
    ];
});
